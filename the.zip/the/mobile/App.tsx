import React, { useState } from 'react';
import { ActivityIndicator, StatusBar, StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import Animated, { FadeIn } from 'react-native-reanimated';

import { AuthProvider, useAuth } from './src/context/AuthContext';
import LoginScreen from './src/screens/LoginScreen';
import CommandCenterScreen from './src/screens/CommandCenterScreen';
import DossierScreen from './src/screens/DossierScreen';
import LiveCopilotScreen from './src/screens/LiveCopilotScreen';
import { Meeting } from './src/data/meetings';
import { Objective } from './src/data/intel';
import { colors } from './src/theme/tokens';

/**
 * The app is a three-step linear flow — agenda, dossier, live session — so it
 * runs on a small explicit state machine rather than a navigation library.
 */
type Route =
  | { name: 'command' }
  | { name: 'dossier'; meeting: Meeting }
  | { name: 'live'; meeting: Meeting; objectives: Objective[] };

function Flow() {
  const [route, setRoute] = useState<Route>({ name: 'command' });

  switch (route.name) {
    case 'dossier':
      return (
        <Animated.View key="dossier" entering={FadeIn.duration(220)} style={styles.fill}>
          <DossierScreen
            meeting={route.meeting}
            onBack={() => setRoute({ name: 'command' })}
            onStart={(objectives) =>
              setRoute({ name: 'live', meeting: route.meeting, objectives })
            }
          />
        </Animated.View>
      );

    case 'live':
      return (
        <Animated.View key="live" entering={FadeIn.duration(220)} style={styles.fill}>
          <LiveCopilotScreen
            meeting={route.meeting}
            objectives={route.objectives}
            onEnd={() => setRoute({ name: 'command' })}
          />
        </Animated.View>
      );

    default:
      return (
        <Animated.View key="command" entering={FadeIn.duration(220)} style={styles.fill}>
          <CommandCenterScreen onOpenMeeting={(meeting) => setRoute({ name: 'dossier', meeting })} />
        </Animated.View>
      );
  }
}

function AppContent() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={styles.splash}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  return user ? <Flow /> : <LoginScreen />;
}

export default function App() {
  return (
    <SafeAreaProvider>
      <View style={styles.fill}>
        <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  fill: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  splash: {
    flex: 1,
    backgroundColor: colors.bg,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
