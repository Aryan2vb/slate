import React from 'react';
import { StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { alpha, colors, radius, space, type } from '../theme/tokens';

export type PillTone =
  /** Metadata and category tags. Recedes. */
  | 'neutral'
  /** Indigo — anything the user can act on. */
  | 'accent'
  /** Violet->pink. Reserved strictly for AI-generated signal. */
  | 'ai'
  /** Crimson. Recording state only. */
  | 'live'
  /** Green. Confirmations and synced states. */
  | 'success';

interface PillProps {
  label: string;
  tone?: PillTone;
  /** Rendered before the label — an emoji glyph, dot, or small node. */
  icon?: React.ReactNode;
  /** Uppercase eyebrow treatment for category tags. */
  caps?: boolean;
  style?: StyleProp<ViewStyle>;
}

const TONES: Record<Exclude<PillTone, 'ai'>, { bg: string; border: string; fg: string }> = {
  neutral: { bg: colors.surface2, border: colors.border, fg: colors.textSecondary },
  accent: { bg: alpha.accentGlow, border: alpha.accentEdge, fg: '#C7D2FE' },
  live: { bg: alpha.liveGlow, border: alpha.liveEdge, fg: '#FCA5A5' },
  success: { bg: 'rgba(34, 197, 94, 0.12)', border: 'rgba(34, 197, 94, 0.35)', fg: '#86EFAC' },
};

/**
 * The app's status atom. Tone carries meaning — 'ai' is never used for a
 * category tag, and 'live' never appears outside an active recording.
 */
export default function Pill({ label, tone = 'neutral', icon, caps = false, style }: PillProps) {
  const textStyle = [styles.label, caps && styles.caps];

  if (tone === 'ai') {
    return (
      <LinearGradient
        colors={[alpha.aiGlow, 'rgba(236, 72, 153, 0.14)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.base, { borderColor: alpha.aiEdge }, style]}
      >
        {icon ? <View style={styles.icon}>{icon}</View> : null}
        <Text style={[textStyle, { color: '#E9D5FF' }]} numberOfLines={1}>
          {label}
        </Text>
      </LinearGradient>
    );
  }

  const t = TONES[tone];
  return (
    <View style={[styles.base, { backgroundColor: t.bg, borderColor: t.border }, style]}>
      {icon ? <View style={styles.icon}>{icon}</View> : null}
      <Text style={[textStyle, { color: t.fg }]} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingVertical: 5,
    paddingHorizontal: space.md,
    borderRadius: radius.pill,
    borderWidth: 1,
  },
  icon: {
    marginRight: 6,
  },
  label: {
    ...type.meta,
  },
  caps: {
    ...type.eyebrow,
  },
});
