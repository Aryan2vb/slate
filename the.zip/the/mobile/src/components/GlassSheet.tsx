import React from 'react';
import { Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { BlurView } from 'expo-blur';
import Animated, { FadeIn, FadeInDown, FadeOut } from 'react-native-reanimated';
import { alpha, colors, radius, space, type } from '../theme/tokens';

interface GlassSheetProps {
  visible: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children?: React.ReactNode;
}

/**
 * Bottom sheet on a blurred dark scrim, used for permissions and roster
 * detail. Tapping the scrim dismisses; the card itself swallows the tap.
 */
export default function GlassSheet({ visible, onClose, title, subtitle, children }: GlassSheetProps) {
  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose} statusBarTranslucent>
      <Animated.View entering={FadeIn.duration(180)} exiting={FadeOut.duration(140)} style={styles.fill}>
        {/* BlurView has no effect on web, so a solid scrim backs it everywhere. */}
        <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill}>
          <View style={[StyleSheet.absoluteFill, { backgroundColor: Platform.OS === 'web' ? colors.bg + 'E6' : alpha.scrimSoft }]} />
        </BlurView>

        <Pressable style={styles.fill} onPress={onClose} accessibilityLabel="Dismiss" />

        <Animated.View entering={FadeInDown.duration(280).springify().damping(16)} style={styles.sheetWrap}>
          <Pressable style={styles.sheet} onPress={() => {}}>
            <View style={styles.grabber} />
            {title ? <Text style={styles.title}>{title}</Text> : null}
            {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
            {children}
          </Pressable>
        </Animated.View>
      </Animated.View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  fill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'flex-end',
  },
  sheetWrap: {
    padding: space.md,
  },
  sheet: {
    backgroundColor: colors.surface1,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: space.xxl,
    paddingTop: space.md,
    paddingBottom: space.xxxl,
  },
  grabber: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    marginBottom: space.xl,
  },
  title: {
    ...type.title,
    color: colors.text,
    marginBottom: space.xs,
  },
  subtitle: {
    ...type.body,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: space.xl,
  },
});
