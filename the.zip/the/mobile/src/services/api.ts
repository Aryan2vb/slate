const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3001';

export interface User {
  id: string;
  email: string;
  name: string;
  picture: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  attendeeCount: number;
  location?: string;
  htmlLink?: string;
}

export const getAuthHeaders = (token: string) => {
  return {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
};

export const authenticateWithGoogle = async (code: string): Promise<{ token: string; user: User }> => {
  try {
    const response = await fetch(`${API_URL}/api/auth/google`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code }),
    });
    
    if (!response.ok) {
      throw new Error(`Authentication failed with status ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error authenticating with Google:', error);
    throw error;
  }
};

export const fetchCalendarEvents = async (token: string): Promise<CalendarEvent[]> => {
  try {
    const response = await fetch(`${API_URL}/api/calendar/events`, {
      method: 'GET',
      headers: getAuthHeaders(token),
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch events with status ${response.status}`);
    }
    
    const data = await response.json();
    // Backend returns { events: [...] }, extract the array
    return data.events;
  } catch (error) {
    console.error('Error fetching calendar events:', error);
    throw error;
  }
};
