import { Person } from '../components/Avatar';
import { Meeting, SEQUOIA_ROSTER } from './meetings';

/* ------------------------------------------------------------------ */
/* Pre-meeting dossier                                                 */
/* ------------------------------------------------------------------ */

export interface Objective {
  id: string;
  /** The question to ask, phrased so it can be read aloud verbatim. */
  question: string;
  /** Why the copilot surfaced it. Shown under the question. */
  rationale: string;
}

export interface Dossier {
  /** Block A: what happened last time, in at most two lines. */
  context: string[];
  /** Block B: the roster, with enough bio to walk in warm. */
  roster: Person[];
  /** Block C: suggested questions the user can flag before walking in. */
  objectives: Objective[];
  /** Prior touchpoints with this group, shown on the roster detail sheet. */
  commonTopics: Record<string, string[]>;
}

const SEQUOIA_DOSSIER: Dossier = {
  context: [
    'Discussed the $2M ARR milestone; John asked for a unit economics breakdown before the partner meeting.',
    'Anita flagged concentration risk — top 3 logos were 41% of revenue last quarter.',
  ],
  roster: SEQUOIA_ROSTER,
  objectives: [
    {
      id: 'obj-cac',
      question: 'What payback period would you need to see to lead the round?',
      rationale: 'John asked for unit economics twice. Naming his bar first anchors the conversation.',
    },
    {
      id: 'obj-concentration',
      question: 'How are you weighting logo concentration against our net revenue retention?',
      rationale: "Anita's open objection from the last call. Unaddressed since March.",
    },
    {
      id: 'obj-timeline',
      question: 'What does your diligence timeline look like if we move this month?',
      rationale: 'No close date has been discussed yet. You need one to run a process.',
    },
  ],
  commonTopics: {
    'p-roelof': ['Unit economics', 'Payback period', 'Series A structure'],
    'p-anita': ['Logo concentration', 'Net revenue retention', 'EMEA expansion'],
    'p-devin': ['Burn multiple', 'Runway to 24 months', 'Headcount plan'],
    'p-mira': ['Pipeline coverage', 'Enterprise motion', 'Win rates'],
  },
};

/**
 * Generic dossier for a real calendar event, where we have no researched
 * intel. It stays honest: the copy says what the copilot *doesn't* know rather
 * than inventing a history the user would catch.
 */
function genericDossier(meeting: Meeting): Dossier {
  return {
    context: [
      `No prior Nabla recording found for ${meeting.org ?? meeting.title}. This will be the first session on file.`,
      `${meeting.people.length} on the invite · ${meeting.location ?? 'No location set'}.`,
    ],
    roster: meeting.people,
    objectives: [
      {
        id: `${meeting.id}-obj-outcome`,
        question: 'What would make this meeting a success for you?',
        rationale: 'Opens with their agenda, and gives you the real success criteria in the first minute.',
      },
      {
        id: `${meeting.id}-obj-blocker`,
        question: "What's the biggest thing standing in the way right now?",
        rationale: 'Surfaces objections early, while there is still time to handle them.',
      },
      {
        id: `${meeting.id}-obj-next`,
        question: 'Who else needs to be in the room before we can move?',
        rationale: 'Identifies hidden approvers before you commit to a next step.',
      },
    ],
    commonTopics: {},
  };
}

export function dossierFor(meeting: Meeting): Dossier {
  return meeting.id === 'sample-sequoia' ? SEQUOIA_DOSSIER : genericDossier(meeting);
}

/* ------------------------------------------------------------------ */
/* Live note stream                                                    */
/* ------------------------------------------------------------------ */

export type NoteKind = 'action' | 'metric' | 'decision' | 'note';

export interface LiveNote {
  id: string;
  text: string;
  kind: NoteKind;
  speaker?: string;
  /** Seconds into the recording. */
  at: number;
  /** True when the user flagged it by hand rather than the copilot. */
  manual?: boolean;
}

export const NOTE_LABELS: Record<NoteKind, string> = {
  action: 'Action Item',
  metric: 'Key Metric',
  decision: 'Decision',
  note: 'Note',
};

/**
 * The scripted transcript the live screen plays back, one entry every few
 * seconds. Swapping this array for a websocket feed is the only change needed
 * to go from simulated to real.
 */
export const SCRIPTED_STREAM: Omit<LiveNote, 'at'>[] = [
  { id: 'n1', kind: 'note', speaker: 'John Mercer', text: 'Opened by asking how the last two quarters compare on net new logos.' },
  { id: 'n2', kind: 'metric', speaker: 'You', text: 'ARR at $2.1M, up from $1.4M at the last check-in — 50% growth over two quarters.' },
  { id: 'n3', kind: 'note', speaker: 'Anita Rao', text: 'Pushed on whether growth is coming from expansion or new business.' },
  { id: 'n4', kind: 'metric', speaker: 'You', text: 'Net revenue retention is 128%; roughly 60% of new ARR came from expansion.' },
  { id: 'n5', kind: 'action', speaker: 'John Mercer', text: 'Send the cohort-level unit economics breakdown before Monday partner meeting.' },
  { id: 'n6', kind: 'note', speaker: 'Anita Rao', text: 'Raised logo concentration again — wants top-3 exposure under 30% by year end.' },
  { id: 'n7', kind: 'decision', speaker: 'You', text: 'Agreed to cap any single logo at 15% of ARR in the FY plan.' },
  { id: 'n8', kind: 'metric', speaker: 'Devin OConnell', text: 'Burn multiple is 1.3x with 22 months of runway at the current plan.' },
  { id: 'n9', kind: 'action', speaker: 'Anita Rao', text: 'Intro to two reference customers in EMEA for diligence calls next week.' },
  { id: 'n10', kind: 'decision', speaker: 'John Mercer', text: 'Sequoia will come back with a term sheet indication within ten days.' },
  { id: 'n11', kind: 'note', speaker: 'Mira Sandoval', text: 'Noted that enterprise win rate improved to 34% after the new pricing tiers.' },
  { id: 'n12', kind: 'action', speaker: 'You', text: 'Circulate the updated FY plan with the concentration cap baked in.' },
];
