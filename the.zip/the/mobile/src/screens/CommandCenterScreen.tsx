import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Animated, { FadeInDown, LinearTransition } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useAuth } from '../context/AuthContext';
import { fetchCalendarEvents } from '../services/api';
import {
  Meeting,
  SAMPLE_AGENDA,
  formatCountdown,
  formatRange,
  toMeeting,
} from '../data/meetings';
import { alpha, colors, layoutSpring, radius, space, type } from '../theme/tokens';
import { Avatar, AvatarStack } from '../components/Avatar';
import Breathe from '../components/Breathe';
import GlassSheet from '../components/GlassSheet';
import GradientBorder from '../components/GradientBorder';
import Icon from '../components/Icon';
import Pill from '../components/Pill';
import PressableScale from '../components/PressableScale';
import useNow from '../hooks/useNow';

interface CommandCenterScreenProps {
  onOpenMeeting: (meeting: Meeting) => void;
}

type SyncState =
  | { status: 'idle' }
  | { status: 'syncing' }
  | { status: 'synced'; at: Date }
  | { status: 'sample'; reason: string };

/**
 * Screen 1 — today's executive agenda.
 *
 * Loads the real calendar and falls back to the sample agenda when the backend
 * is unreachable or the day is empty, so the screen is never a dead end.
 */
export default function CommandCenterScreen({ onOpenMeeting }: CommandCenterScreenProps) {
  const { user, token, signOut } = useAuth();
  const insets = useSafeAreaInsets();
  const now = useNow();

  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [sync, setSync] = useState<SyncState>({ status: 'idle' });
  const [loading, setLoading] = useState(true);
  const [profileOpen, setProfileOpen] = useState(false);

  const load = useCallback(async () => {
    if (!token) {
      setMeetings(SAMPLE_AGENDA);
      setSync({ status: 'sample', reason: 'Not signed in' });
      setLoading(false);
      return;
    }

    setSync({ status: 'syncing' });
    try {
      const events = await fetchCalendarEvents(token);
      const mapped = events.map(toMeeting);

      if (mapped.length === 0) {
        // An empty calendar is a valid answer, but an empty screen isn't a
        // useful one — show the sample agenda and say so.
        setMeetings(SAMPLE_AGENDA);
        setSync({ status: 'sample', reason: 'Nothing on your calendar' });
      } else {
        setMeetings(mapped);
        setSync({ status: 'synced', at: new Date() });
      }
    } catch {
      setMeetings(SAMPLE_AGENDA);
      setSync({ status: 'sample', reason: 'Calendar unavailable' });
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    void load();
  }, [load]);

  /** Upcoming meetings first; anything already finished drops off the feed. */
  const upcoming = useMemo(
    () =>
      [...meetings]
        .filter((m) => m.endTime.getTime() > now.getTime())
        .sort((a, b) => a.startTime.getTime() - b.startTime.getTime()),
    [meetings, now],
  );

  const [hero, ...rest] = upcoming;

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: insets.top + space.md, paddingBottom: insets.bottom + space.xxxl },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={sync.status === 'syncing' && !loading}
            onRefresh={load}
            tintColor={colors.textMuted}
          />
        }
      >
        <Header
          user={user}
          sync={sync}
          now={now}
          onPressProfile={() => setProfileOpen(true)}
        />

        {loading ? (
          <View style={styles.loading}>
            <ActivityIndicator color={colors.accent} />
            <Text style={styles.loadingText}>Reading your calendar…</Text>
          </View>
        ) : (
          <>
            {hero ? (
              <HeroCard meeting={hero} now={now} onPress={() => onOpenMeeting(hero)} />
            ) : (
              <View style={styles.empty}>
                <Text style={styles.emptyTitle}>The rest of your day is clear.</Text>
                <Text style={styles.emptyBody}>
                  Nothing else on the calendar. Pull down to re-sync.
                </Text>
              </View>
            )}

            {rest.length > 0 ? (
              <>
                <Text style={styles.sectionLabel}>LATER TODAY</Text>
                <View style={styles.timeline}>
                  <View style={styles.axis} />
                  {rest.map((meeting, index) => (
                    <TimelineRow
                      key={meeting.id}
                      meeting={meeting}
                      index={index}
                      onPress={() => onOpenMeeting(meeting)}
                    />
                  ))}
                </View>
              </>
            ) : null}
          </>
        )}
      </ScrollView>

      <GlassSheet
        visible={profileOpen}
        onClose={() => setProfileOpen(false)}
        title={user?.name ?? 'Signed in'}
        subtitle={user?.email}
      >
        <PressableScale
          style={styles.signOut}
          haptic="primary"
          onPress={() => {
            setProfileOpen(false);
            void signOut();
          }}
        >
          <Text style={styles.signOutText}>Sign out</Text>
        </PressableScale>
      </GlassSheet>
    </View>
  );
}

/* ------------------------------------------------------------------ */

function Header({
  user,
  sync,
  now,
  onPressProfile,
}: {
  user: { name?: string; picture?: string } | null;
  sync: SyncState;
  now: Date;
  onPressProfile: () => void;
}) {
  const label = (() => {
    switch (sync.status) {
      case 'syncing':
        return 'Syncing…';
      case 'synced': {
        const mins = Math.max(0, Math.round((now.getTime() - sync.at.getTime()) / 60_000));
        return mins < 1 ? 'Synced just now' : `Synced ${mins}m ago`;
      }
      case 'sample':
        return 'Sample agenda';
      default:
        return 'Calendar';
    }
  })();

  const hour = now.getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const firstName = user?.name?.split(' ')[0];

  return (
    <View style={styles.header}>
      <View style={styles.headerRow}>
        <PressableScale
          haptic="select"
          onPress={onPressProfile}
          style={styles.profile}
          accessibilityLabel="Account"
        >
          <Avatar
            person={{ id: 'me', name: user?.name ?? 'You', avatarUrl: user?.picture }}
            size={40}
            showBrand={false}
            ringColor={colors.border}
          />
          <View style={styles.presence} />
        </PressableScale>

        <Pill
          label={label}
          tone={sync.status === 'sample' ? 'neutral' : 'success'}
          icon={
            <View style={styles.syncIcon}>
              <Icon
                name="calendar"
                size={12}
                color={sync.status === 'sample' ? colors.textMuted : colors.presence}
              />
              <View
                style={[
                  styles.syncDot,
                  { backgroundColor: sync.status === 'sample' ? colors.textMuted : colors.presence },
                ]}
              />
            </View>
          }
        />
      </View>

      <Text style={styles.greeting}>
        {greeting}
        {firstName ? `, ${firstName}` : ''}
      </Text>
      {sync.status === 'sample' ? (
        <Text style={styles.sampleNote}>{sync.reason} — showing a sample day.</Text>
      ) : null}
    </View>
  );
}

/* ------------------------------------------------------------------ */

function HeroCard({
  meeting,
  now,
  onPress,
}: {
  meeting: Meeting;
  now: Date;
  onPress: () => void;
}) {
  const countdown = formatCountdown(meeting.startTime, meeting.endTime, now);
  const imminent = countdown === 'Now' || countdown === 'Starting';

  return (
    <Animated.View entering={FadeInDown.duration(420)} layout={LinearTransition.springify().damping(layoutSpring.damping)}>
      <Text style={styles.sectionLabel}>NEXT UP</Text>
      <PressableScale onPress={onPress} haptic="primary" accessibilityRole="button">
        <GradientBorder
          colorsRamp={[colors.aiFrom, colors.accent]}
          radius={radius.xl}
          width={1.5}
          innerStyle={styles.heroInner}
        >
          <View style={styles.heroTopRow}>
            <Pill
              label={formatRange(meeting)}
              tone="neutral"
              style={styles.heroRangePill}
            />
            <Pill label={countdown} tone={imminent ? 'live' : 'accent'} caps />
          </View>

          <Text style={styles.heroTitle}>{meeting.title}</Text>
          {meeting.org ? <Text style={styles.heroOrg}>{meeting.org}</Text> : null}

          <View style={styles.heroMeta}>
            <AvatarStack people={meeting.people} size={34} ringColor={colors.surface1} />
            {meeting.location ? (
              <Text style={styles.heroLocation}>{meeting.location}</Text>
            ) : null}
          </View>

          <View style={styles.heroDivider} />

          <Pill
            label="Pre-Meeting Brief Ready"
            tone="ai"
            icon={
              <Breathe>
                <Icon name="sparkles" size={12} color="#E9D5FF" />
              </Breathe>
            }
          />
        </GradientBorder>
      </PressableScale>
    </Animated.View>
  );
}

/* ------------------------------------------------------------------ */

function TimelineRow({
  meeting,
  index,
  onPress,
}: {
  meeting: Meeting;
  index: number;
  onPress: () => void;
}) {
  return (
    <Animated.View
      entering={FadeInDown.duration(360).delay(60 * index)}
      layout={LinearTransition.springify().damping(layoutSpring.damping)}
      style={styles.timelineRow}
    >
      <View style={styles.timelineGutter}>
        <Text style={styles.timelineTime}>
          {meeting.startTime.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
        </Text>
        <View style={styles.node} />
      </View>

      <PressableScale onPress={onPress} haptic="select" style={styles.eventCardWrap}>
        <View style={styles.eventCard}>
          <Text style={styles.eventTitle} numberOfLines={2}>
            {meeting.title}
          </Text>
          {meeting.org ? <Text style={styles.eventOrg}>{meeting.org}</Text> : null}

          <View style={styles.eventFooter}>
            <View style={styles.tagRow}>
              {meeting.tags.map((tag) => (
                <Pill key={tag} label={tag} caps style={styles.tag} />
              ))}
            </View>
            <AvatarStack people={meeting.people} size={24} max={3} ringColor={colors.surface1} />
          </View>
        </View>
      </PressableScale>
    </Animated.View>
  );
}

/* ------------------------------------------------------------------ */

const GUTTER = 62;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scroll: { paddingHorizontal: space.xl },

  header: { marginBottom: space.xxl },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: space.xl,
  },
  profile: { width: 40, height: 40 },
  presence: {
    position: 'absolute',
    right: -1,
    bottom: -1,
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: colors.presence,
    borderWidth: 2,
    borderColor: colors.bg,
  },
  syncIcon: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  syncDot: { width: 6, height: 6, borderRadius: 3 },
  greeting: { ...type.display, color: colors.text },
  sampleNote: { ...type.meta, color: colors.textMuted, marginTop: space.xs },

  sectionLabel: {
    ...type.eyebrow,
    color: colors.textMuted,
    marginBottom: space.md,
    marginTop: space.sm,
  },

  heroInner: { padding: space.xl },
  heroTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: space.lg,
  },
  heroRangePill: { flexShrink: 1, marginRight: space.sm },
  heroTitle: { ...type.title, fontSize: 22, color: colors.text, marginBottom: space.xs },
  heroOrg: { ...type.body, color: colors.textSecondary, marginBottom: space.lg },
  heroMeta: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  heroLocation: { ...type.meta, color: colors.textMuted },
  heroDivider: {
    height: 1,
    backgroundColor: alpha.hairline,
    marginVertical: space.lg,
  },

  timeline: { position: 'relative' },
  axis: {
    position: 'absolute',
    left: GUTTER - 1,
    top: 8,
    bottom: 8,
    width: 1,
    backgroundColor: colors.border,
  },
  timelineRow: { flexDirection: 'row', marginBottom: space.md },
  timelineGutter: {
    width: GUTTER,
    paddingRight: space.md,
    alignItems: 'flex-end',
    paddingTop: space.lg,
  },
  timelineTime: { ...type.meta, color: colors.textMuted },
  node: {
    position: 'absolute',
    right: -4,
    top: space.lg + 3,
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.border,
    borderWidth: 2,
    borderColor: colors.bg,
  },
  eventCardWrap: { flex: 1, marginLeft: space.md },
  eventCard: {
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.lg,
  },
  eventTitle: { ...type.heading, color: colors.text },
  eventOrg: { ...type.meta, color: colors.textMuted, marginTop: 2 },
  eventFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: space.lg,
    gap: space.sm,
  },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, flexShrink: 1 },
  tag: { paddingVertical: 4 },

  loading: { paddingVertical: 80, alignItems: 'center', gap: space.md },
  loadingText: { ...type.body, color: colors.textMuted },

  empty: {
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.xxl,
  },
  emptyTitle: { ...type.heading, color: colors.text, marginBottom: space.xs },
  emptyBody: { ...type.body, color: colors.textSecondary, lineHeight: 20 },

  signOut: {
    backgroundColor: colors.surface2,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingVertical: space.lg,
    alignItems: 'center',
  },
  signOutText: { ...type.heading, color: colors.live },
});
