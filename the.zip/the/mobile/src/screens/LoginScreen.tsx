import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import * as Google from 'expo-auth-session/providers/google';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  Easing,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useAuth } from '../context/AuthContext';
import GlassSheet from '../components/GlassSheet';
import Icon from '../components/Icon';
import PressableScale from '../components/PressableScale';
import { alpha, colors, radius, space, type } from '../theme/tokens';

// Completes the auth session when control returns from the browser.
WebBrowser.maybeCompleteAuthSession();

export default function LoginScreen() {
  const { signIn } = useAuth();
  const insets = useSafeAreaInsets();

  const [isSigningIn, setIsSigningIn] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [explainerOpen, setExplainerOpen] = useState(false);

  // Expo AuthSession proxies OAuth through a web redirect, so the Web client
  // ID is required here even on native.
  const [request, response, promptAsync] = Google.useAuthRequest({
    webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
    scopes: ['email', 'profile', 'https://www.googleapis.com/auth/calendar.readonly'],
  });

  useEffect(() => {
    if (response?.type === 'success') {
      const { code } = response.params;
      void handleSignIn(code);
    } else if (response?.type === 'error') {
      setError('Google turned down the sign-in request. Please try again.');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [response]);

  const handleSignIn = async (code: string) => {
    setIsSigningIn(true);
    setError(null);
    try {
      await signIn(code);
      // On success this screen unmounts, so no need to reset state.
    } catch {
      setError('Could not reach the Nabla server. Check that it is running.');
      setIsSigningIn(false);
    }
  };

  return (
    <View style={styles.container}>
      <AmbientOrbs />

      <View style={[styles.content, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
        <Animated.View entering={FadeInDown.duration(520)} style={styles.brandBlock}>
          <LinearGradient
            colors={[colors.aiFrom, colors.accent]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.mark}
          >
            <Text style={styles.markGlyph}>∇</Text>
          </LinearGradient>

          <Text style={styles.wordmark}>Nabla</Text>
          <Text style={styles.tagline}>
            Your executive meeting copilot. Briefed before you walk in, listening while you talk.
          </Text>
        </Animated.View>

        <Animated.View entering={FadeInDown.duration(520).delay(140)} style={styles.actions}>
          {isSigningIn ? (
            <View style={styles.signingIn}>
              <ActivityIndicator color={colors.accent} />
              <Text style={styles.signingInText}>Connecting your calendar…</Text>
            </View>
          ) : (
            <PressableScale
              haptic="primary"
              onPress={() => setExplainerOpen(true)}
              disabled={!request}
              style={styles.cta}
            >
              <Icon name="google" size={16} color={colors.text} />
              <Text style={styles.ctaText}>Continue with Google</Text>
            </PressableScale>
          )}

          {error ? <Text style={styles.error}>{error}</Text> : null}

          <Text style={styles.footnote}>
            Read-only calendar access. Nabla never writes to your calendar.
          </Text>
        </Animated.View>
      </View>

      {/* Permission explainer — states what we ask for before the OS prompt. */}
      <GlassSheet
        visible={explainerOpen}
        onClose={() => setExplainerOpen(false)}
        title="Connect Google Calendar"
        subtitle="Nabla reads your upcoming events to build pre-meeting briefs. It requests read-only access and nothing else."
      >
        <View style={styles.scopeList}>
          <ScopeRow label="See your calendar events" detail="calendar.readonly" />
          <ScopeRow label="Your name and email" detail="profile · email" />
        </View>

        <PressableScale
          haptic="primary"
          onPress={() => {
            setExplainerOpen(false);
            // Presenting the auth browser while the modal is still dismissing
            // can fail silently on iOS, so let the dismissal land first.
            setTimeout(() => void promptAsync(), 260);
          }}
          style={styles.cta}
        >
          <Text style={styles.ctaText}>Continue</Text>
        </PressableScale>
      </GlassSheet>
    </View>
  );
}

function ScopeRow({ label, detail }: { label: string; detail: string }) {
  return (
    <View style={styles.scopeRow}>
      <View style={styles.scopeDot} />
      <View style={{ flex: 1 }}>
        <Text style={styles.scopeLabel}>{label}</Text>
        <Text style={styles.scopeDetail}>{detail}</Text>
      </View>
    </View>
  );
}

/** Two slow-drifting colour fields behind the content. */
function AmbientOrbs() {
  const drift = useSharedValue(0);

  useEffect(() => {
    drift.value = withRepeat(
      withTiming(1, { duration: 9000, easing: Easing.inOut(Easing.sin) }),
      -1,
      true,
    );
  }, [drift]);

  const orbA = useAnimatedStyle(() => ({
    transform: [{ translateY: -30 * drift.value }, { scale: 1 + 0.08 * drift.value }],
  }));
  const orbB = useAnimatedStyle(() => ({
    transform: [{ translateY: 40 * drift.value }, { scale: 1.08 - 0.08 * drift.value }],
  }));

  return (
    <>
      <Animated.View style={[styles.orbA, orbA]} />
      <Animated.View style={[styles.orbB, orbB]} />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, overflow: 'hidden' },

  orbA: {
    position: 'absolute',
    top: 60,
    left: -90,
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: 'rgba(99, 102, 241, 0.13)',
  },
  orbB: {
    position: 'absolute',
    bottom: 40,
    right: -80,
    width: 320,
    height: 320,
    borderRadius: 160,
    backgroundColor: 'rgba(139, 92, 246, 0.11)',
  },

  content: {
    flex: 1,
    paddingHorizontal: space.xxl,
    justifyContent: 'space-between',
  },
  brandBlock: { flex: 1, justifyContent: 'center' },
  mark: {
    width: 56,
    height: 56,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: space.xxl,
  },
  markGlyph: { color: colors.text, fontSize: 28, fontWeight: '700' },
  wordmark: { ...type.display, fontSize: 42, color: colors.text, marginBottom: space.md },
  tagline: {
    ...type.body,
    fontSize: 15,
    color: colors.textSecondary,
    lineHeight: 23,
    maxWidth: 320,
  },

  actions: { paddingBottom: space.xxl, gap: space.lg },
  cta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: space.md,
    backgroundColor: colors.accent,
    borderRadius: radius.pill,
    paddingVertical: space.lg,
    borderWidth: 1,
    borderColor: '#818CF8',
    shadowColor: colors.accent,
    shadowOpacity: 0.45,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  ctaText: { ...type.heading, color: colors.text },

  signingIn: { alignItems: 'center', gap: space.md, paddingVertical: space.lg },
  signingInText: { ...type.body, color: colors.textSecondary },

  error: {
    ...type.meta,
    color: '#FCA5A5',
    backgroundColor: alpha.liveGlow,
    borderWidth: 1,
    borderColor: alpha.liveEdge,
    borderRadius: radius.sm,
    padding: space.md,
    lineHeight: 17,
  },
  footnote: { ...type.meta, color: colors.textMuted, textAlign: 'center' },

  scopeList: { gap: space.lg, marginBottom: space.xxl },
  scopeRow: { flexDirection: 'row', alignItems: 'flex-start', gap: space.md },
  scopeDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.accent,
    marginTop: 7,
  },
  scopeLabel: { ...type.body, color: colors.text },
  scopeDetail: { ...type.meta, color: colors.textMuted, marginTop: 2 },
});
