import React, { useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Avatar, Person } from '../components/Avatar';
import Breathe from '../components/Breathe';
import GlassSheet from '../components/GlassSheet';
import Icon from '../components/Icon';
import Pill from '../components/Pill';
import PressableScale from '../components/PressableScale';
import { Dossier, Objective, dossierFor } from '../data/intel';
import { Meeting, formatCountdown, formatRange } from '../data/meetings';
import { alpha, colors, radius, space, spring, type } from '../theme/tokens';
import useNow from '../hooks/useNow';

interface DossierScreenProps {
  meeting: Meeting;
  onBack: () => void;
  /** Receives the objectives the user flagged, to carry into the live screen. */
  onStart: (flagged: Objective[]) => void;
}

/**
 * Screen 2 — the pre-meeting intel sheet.
 *
 * A bento of four blocks: two stat tiles, the context recap, the roster, and
 * the objective checklist. Flagged objectives travel with the user into the
 * live session.
 */
export default function DossierScreen({ meeting, onBack, onStart }: DossierScreenProps) {
  const insets = useSafeAreaInsets();
  const now = useNow();
  const dossier: Dossier = useMemo(() => dossierFor(meeting), [meeting]);

  const [flagged, setFlagged] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState<Person | null>(null);

  const toggle = (id: string) =>
    setFlagged((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const durationMins = Math.max(
    1,
    Math.round((meeting.endTime.getTime() - meeting.startTime.getTime()) / 60_000),
  );

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: insets.top + space.md, paddingBottom: insets.bottom + 120 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <PressableScale haptic="select" onPress={onBack} style={styles.back}>
            <Icon name="chevron-left" size={20} color={colors.text} />
          </PressableScale>
          <Pill
            label="AI Dossier"
            tone="ai"
            caps
            icon={
              <Breathe>
                <Icon name="sparkles" size={11} color="#E9D5FF" />
              </Breathe>
            }
          />
        </View>

        <Animated.View entering={FadeInDown.duration(360)}>
          <Text style={styles.title}>{meeting.title}</Text>
          <Text style={styles.subtitle}>
            {meeting.org ? `${meeting.org} · ` : ''}
            {formatRange(meeting)}
          </Text>
        </Animated.View>

        {/* Bento row: two stat tiles */}
        <Animated.View entering={FadeInDown.duration(360).delay(60)} style={styles.statRow}>
          <StatTile
            label="STARTS"
            value={formatCountdown(meeting.startTime, meeting.endTime, now)}
            accent
          />
          <StatTile label="DURATION" value={`${durationMins}m`} />
        </Animated.View>

        {/* Block A — key context */}
        <Block title="KEY CONTEXT" delay={120}>
          {dossier.context.map((line, index) => (
            <View key={index} style={styles.bullet}>
              <View style={styles.bulletDot} />
              <Text style={styles.bulletText}>{line}</Text>
            </View>
          ))}
        </Block>

        {/* Block B — roster */}
        <Block title="WHO'S IN THE ROOM" delay={180} flush>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.rosterScroll}
          >
            {dossier.roster.map((person) => (
              <PressableScale
                key={person.id}
                haptic="select"
                onPress={() => setSelected(person)}
                style={styles.rosterCard}
              >
                <Avatar person={person} size={46} ringColor={colors.surface2} />
                <Text style={styles.rosterName} numberOfLines={1}>
                  {person.name}
                </Text>
                <Text style={styles.rosterTitle} numberOfLines={2}>
                  {person.title ?? 'Attendee'}
                </Text>
                {person.company ? (
                  <Text style={styles.rosterCompany} numberOfLines={1}>
                    {person.company}
                  </Text>
                ) : null}
              </PressableScale>
            ))}
          </ScrollView>
        </Block>

        {/* Block C — objectives */}
        <Block
          title="SUGGESTED OBJECTIVES"
          delay={240}
          trailing={
            flagged.size > 0 ? <Pill label={`${flagged.size} flagged`} tone="accent" caps /> : null
          }
        >
          {dossier.objectives.map((objective) => (
            <ObjectiveRow
              key={objective.id}
              objective={objective}
              checked={flagged.has(objective.id)}
              onToggle={() => toggle(objective.id)}
            />
          ))}
        </Block>
      </ScrollView>

      {/* Floating dock CTA */}
      <Animated.View
        entering={FadeIn.duration(400).delay(300)}
        style={[styles.dock, { paddingBottom: insets.bottom + space.md }]}
      >
        <PressableScale
          haptic="primary"
          onPress={() =>
            onStart(dossier.objectives.filter((objective) => flagged.has(objective.id)))
          }
          style={styles.cta}
        >
          <View style={styles.ctaGlyph}>
            <Icon name="mic" size={13} color={colors.text} />
          </View>
          <Text style={styles.ctaText}>Start Meeting Copilot</Text>
        </PressableScale>
      </Animated.View>

      {/* Roster detail */}
      <GlassSheet
        visible={selected !== null}
        onClose={() => setSelected(null)}
        title={selected?.name}
        subtitle={
          selected
            ? [selected.title, selected.company].filter(Boolean).join(' · ') || 'On the invite'
            : undefined
        }
      >
        {selected ? (
          <View>
            <Text style={styles.sheetLabel}>PAST COMMON TOPICS</Text>
            <View style={styles.topicRow}>
              {(dossier.commonTopics[selected.id] ?? []).length > 0 ? (
                dossier.commonTopics[selected.id].map((topic) => (
                  <Pill key={topic} label={topic} tone="neutral" />
                ))
              ) : (
                <Text style={styles.sheetEmpty}>
                  No shared history on file yet. Nabla will start building one after this meeting.
                </Text>
              )}
            </View>
          </View>
        ) : null}
      </GlassSheet>
    </View>
  );
}

/* ------------------------------------------------------------------ */

function StatTile({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <View style={[styles.statTile, accent && styles.statTileAccent]}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={[styles.statValue, accent && { color: '#C7D2FE' }]}>{value}</Text>
    </View>
  );
}

function Block({
  title,
  children,
  delay,
  trailing,
  flush,
}: {
  title: string;
  children: React.ReactNode;
  delay: number;
  trailing?: React.ReactNode;
  /** Lets a horizontal scroller bleed to the card edges. */
  flush?: boolean;
}) {
  return (
    <Animated.View entering={FadeInDown.duration(360).delay(delay)} style={styles.block}>
      <View style={styles.blockHeader}>
        <Text style={styles.blockTitle}>{title}</Text>
        {trailing}
      </View>
      <View style={flush ? undefined : styles.blockBody}>{children}</View>
    </Animated.View>
  );
}

function ObjectiveRow({
  objective,
  checked,
  onToggle,
}: {
  objective: Objective;
  checked: boolean;
  onToggle: () => void;
}) {
  const mark = useSharedValue(checked ? 1 : 0);

  const markStyle = useAnimatedStyle(() => ({
    opacity: mark.value,
    transform: [{ scale: mark.value }],
  }));

  const handlePress = () => {
    mark.value = withSpring(checked ? 0 : 1, spring);
    onToggle();
  };

  return (
    <PressableScale
      // Flagging is a small win; un-flagging is just a correction.
      haptic={checked ? 'select' : 'flag'}
      onPress={handlePress}
      pressScale={0.985}
      style={[styles.objective, checked && styles.objectiveChecked]}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
    >
      <View style={[styles.checkbox, checked && styles.checkboxChecked]}>
        <Animated.View style={markStyle}>
          <Icon name="check" size={13} color={colors.text} />
        </Animated.View>
      </View>
      <View style={styles.objectiveBody}>
        <Text style={[styles.objectiveText, checked && styles.objectiveTextChecked]}>
          {objective.question}
        </Text>
        <Text style={styles.objectiveWhy}>{objective.rationale}</Text>
      </View>
    </PressableScale>
  );
}

/* ------------------------------------------------------------------ */

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scroll: { paddingHorizontal: space.xl },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: space.xl,
  },
  back: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.surface1,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },

  title: { ...type.display, fontSize: 26, color: colors.text },
  subtitle: { ...type.body, color: colors.textSecondary, marginTop: space.xs },

  statRow: { flexDirection: 'row', gap: space.md, marginTop: space.xl },
  statTile: {
    flex: 1,
    backgroundColor: colors.surface1,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: space.lg,
    paddingHorizontal: space.lg,
  },
  statTileAccent: { backgroundColor: alpha.accentGlow, borderColor: alpha.accentEdge },
  statLabel: { ...type.eyebrow, color: colors.textMuted, marginBottom: 6 },
  statValue: { ...type.title, color: colors.text },

  block: {
    marginTop: space.xxl,
    backgroundColor: colors.surface1,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: space.lg,
  },
  blockHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: space.lg,
    marginBottom: space.md,
  },
  blockTitle: { ...type.eyebrow, color: colors.textMuted },
  blockBody: { paddingHorizontal: space.lg },

  bullet: { flexDirection: 'row', gap: space.md, marginBottom: space.md },
  bulletDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.aiFrom,
    marginTop: 7,
  },
  bulletText: { ...type.body, color: colors.text, lineHeight: 21, flex: 1 },

  rosterScroll: { paddingHorizontal: space.lg, gap: space.md },
  rosterCard: {
    width: 138,
    backgroundColor: colors.surface2,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.lg,
  },
  rosterName: { ...type.heading, color: colors.text, marginTop: space.md },
  rosterTitle: { ...type.meta, color: colors.textSecondary, marginTop: 2, lineHeight: 16 },
  rosterCompany: { ...type.meta, color: colors.textMuted, marginTop: 6 },

  objective: {
    flexDirection: 'row',
    gap: space.md,
    padding: space.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'transparent',
    marginBottom: space.sm,
  },
  objectiveChecked: { backgroundColor: alpha.accentGlow, borderColor: alpha.accentEdge },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 7,
    borderWidth: 1.5,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  checkboxChecked: { backgroundColor: colors.accent, borderColor: colors.accent },
  objectiveBody: { flex: 1 },
  objectiveText: { ...type.body, color: colors.text, lineHeight: 20 },
  objectiveTextChecked: { color: '#E0E7FF' },
  objectiveWhy: { ...type.meta, color: colors.textMuted, marginTop: 5, lineHeight: 16 },

  dock: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: space.xl,
    paddingTop: space.md,
    backgroundColor: alpha.scrim,
    borderTopWidth: 1,
    borderTopColor: alpha.hairline,
  },
  cta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: space.md,
    backgroundColor: colors.accent,
    borderRadius: radius.pill,
    paddingVertical: space.lg,
    borderWidth: 1,
    borderColor: '#818CF8',
    shadowColor: colors.accent,
    shadowOpacity: 0.5,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  ctaGlyph: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaText: { ...type.heading, color: colors.text },

  sheetLabel: { ...type.eyebrow, color: colors.textMuted, marginBottom: space.md },
  topicRow: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  sheetEmpty: { ...type.body, color: colors.textSecondary, lineHeight: 20 },
});
