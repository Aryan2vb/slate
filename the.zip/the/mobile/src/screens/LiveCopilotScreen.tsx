import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, LinearTransition } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import GlassSheet from '../components/GlassSheet';
import Icon from '../components/Icon';
import Pill, { PillTone } from '../components/Pill';
import PressableScale from '../components/PressableScale';
import PulseDot from '../components/PulseDot';
import Waveform from '../components/Waveform';
import { LiveNote, NOTE_LABELS, NoteKind, Objective, SCRIPTED_STREAM } from '../data/intel';
import { Meeting, formatElapsed } from '../data/meetings';
import { alpha, colors, layoutSpring, radius, space, type } from '../theme/tokens';
import { tap } from '../theme/haptics';

/** How often the simulated copilot emits a new note. */
const STREAM_INTERVAL_MS = 3000;

const NOTE_TONE: Record<NoteKind, PillTone> = {
  action: 'accent',
  metric: 'ai',
  decision: 'success',
  note: 'neutral',
};

interface LiveCopilotScreenProps {
  meeting: Meeting;
  /** Objectives the user flagged on the dossier, pinned above the feed. */
  objectives: Objective[];
  onEnd: () => void;
}

/**
 * Screen 3 — the in-meeting studio.
 *
 * Notes arrive on a timer to simulate a live transcript. Replacing
 * SCRIPTED_STREAM with a socket feed is the only change needed for the real
 * thing; everything below reacts to the `notes` array.
 */
export default function LiveCopilotScreen({ meeting, objectives, onEnd }: LiveCopilotScreenProps) {
  const insets = useSafeAreaInsets();

  const [elapsed, setElapsed] = useState(0);
  const [paused, setPaused] = useState(false);
  const [notes, setNotes] = useState<LiveNote[]>([]);
  const [wrapUpOpen, setWrapUpOpen] = useState(false);

  const cursor = useRef(0);
  const scrollRef = useRef<ScrollView>(null);
  /** Elapsed is read inside the stream timer without re-arming it each tick. */
  const elapsedRef = useRef(0);
  elapsedRef.current = elapsed;

  /* Recording clock */
  useEffect(() => {
    if (paused) return;
    const id = setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => clearInterval(id);
  }, [paused]);

  /* Simulated transcript feed */
  useEffect(() => {
    if (paused) return;

    const id = setInterval(() => {
      if (cursor.current >= SCRIPTED_STREAM.length) {
        clearInterval(id);
        return;
      }
      const next = SCRIPTED_STREAM[cursor.current];
      cursor.current += 1;
      setNotes((prev) => [...prev, { ...next, at: elapsedRef.current }]);
    }, STREAM_INTERVAL_MS);

    return () => clearInterval(id);
  }, [paused]);

  /* Keep the newest note in view */
  useEffect(() => {
    if (notes.length === 0) return;
    const id = setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
    return () => clearTimeout(id);
  }, [notes.length]);

  const addManual = useCallback(
    (kind: NoteKind, text: string) => {
      tap('flag');
      setNotes((prev) => [
        ...prev,
        { id: `manual-${Date.now()}`, kind, text, at: elapsedRef.current, manual: true },
      ]);
    },
    [],
  );

  const flagAction = () =>
    addManual('action', 'Flagged by you — follow up on the last point discussed.');

  const bookmark = () => {
    const lastSpoken = [...notes].reverse().find((note) => !note.manual);
    addManual(
      'note',
      lastSpoken ? `Bookmarked: “${lastSpoken.text}”` : 'Bookmarked this moment.',
    );
  };

  const handleStop = () => {
    tap('stop');
    setPaused(true);
    setWrapUpOpen(true);
  };

  const counts = {
    action: notes.filter((n) => n.kind === 'action').length,
    decision: notes.filter((n) => n.kind === 'decision').length,
    metric: notes.filter((n) => n.kind === 'metric').length,
  };

  return (
    <View style={styles.container}>
      {/* Top bar */}
      <View style={[styles.topBar, { paddingTop: insets.top + space.md }]}>
        <View style={styles.liveGroup}>
          <PulseDot color={paused ? colors.textMuted : colors.live} size={7} />
          <Text style={[styles.liveLabel, paused && { color: colors.textMuted }]}>
            {paused ? 'PAUSED' : 'LIVE'}
          </Text>
        </View>

        <Text style={styles.timer}>{formatElapsed(elapsed)}</Text>

        <View style={styles.topBarSpacer}>
          <Text style={styles.meetingLabel} numberOfLines={1}>
            {meeting.org ?? meeting.title}
          </Text>
        </View>
      </View>

      {/* Waveform stage */}
      <View style={styles.stage}>
        <Waveform paused={paused} height={92} />
        <Text style={styles.stageCaption}>
          {paused ? 'Recording paused' : 'Listening · transcribing on device'}
        </Text>
      </View>

      {/* Pinned objectives */}
      {objectives.length > 0 ? (
        <Animated.View entering={FadeIn.duration(300)} style={styles.objectiveStrip}>
          <Text style={styles.stripLabel}>YOUR OBJECTIVES</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.stripRow}>
            {objectives.map((objective) => (
              <View key={objective.id} style={styles.stripCard}>
                <Text style={styles.stripText} numberOfLines={2}>
                  {objective.question}
                </Text>
              </View>
            ))}
          </ScrollView>
        </Animated.View>
      ) : null}

      {/* Note stream */}
      <ScrollView
        ref={scrollRef}
        style={styles.feed}
        contentContainerStyle={styles.feedContent}
        showsVerticalScrollIndicator={false}
      >
        {notes.length === 0 ? (
          <View style={styles.feedEmpty}>
            <Text style={styles.feedEmptyText}>
              Nabla is listening. Notes will appear here as the conversation develops.
            </Text>
          </View>
        ) : (
          notes.map((note) => <NoteRow key={note.id} note={note} />)
        )}
      </ScrollView>

      {/* Action dock */}
      <View style={[styles.dock, { paddingBottom: insets.bottom + space.lg }]}>
        <PressableScale haptic={null} onPress={flagAction} style={styles.dockButton}>
          <Icon name="zap" size={17} color={colors.text} style={styles.dockGlyph} />
          <Text style={styles.dockLabel}>Action Item</Text>
        </PressableScale>

        <StopButton onPress={handleStop} paused={paused} />

        <PressableScale haptic={null} onPress={bookmark} style={styles.dockButton}>
          <Icon name="bookmark" size={17} color={colors.text} style={styles.dockGlyph} />
          <Text style={styles.dockLabel}>Bookmark</Text>
        </PressableScale>
      </View>

      {/* Wrap-up */}
      <GlassSheet
        visible={wrapUpOpen}
        onClose={() => {
          setWrapUpOpen(false);
          setPaused(false);
        }}
        title="End this session?"
        subtitle={`${formatElapsed(elapsed)} recorded · ${notes.length} notes captured`}
      >
        <View style={styles.recapRow}>
          <Pill label={`${counts.action} action items`} tone="accent" />
          <Pill label={`${counts.decision} decisions`} tone="success" />
          <Pill label={`${counts.metric} metrics`} tone="ai" />
        </View>

        <PressableScale haptic="stop" onPress={onEnd} style={styles.endButton}>
          <Text style={styles.endButtonText}>End & save summary</Text>
        </PressableScale>

        <PressableScale
          haptic="select"
          onPress={() => {
            setWrapUpOpen(false);
            setPaused(false);
          }}
          style={styles.resumeButton}
        >
          <Text style={styles.resumeText}>Keep recording</Text>
        </PressableScale>
      </GlassSheet>
    </View>
  );
}

/* ------------------------------------------------------------------ */

function NoteRow({ note }: { note: LiveNote }) {
  return (
    <Animated.View
      entering={FadeInDown.duration(300)}
      layout={LinearTransition.springify().damping(layoutSpring.damping)}
      style={[styles.note, note.manual && styles.noteManual]}
    >
      <View style={styles.noteHeader}>
        <Pill label={note.manual ? 'Flagged by you' : NOTE_LABELS[note.kind]} tone={NOTE_TONE[note.kind]} caps />
        <Text style={styles.noteTime}>{formatElapsed(note.at)}</Text>
      </View>
      {note.speaker ? <Text style={styles.noteSpeaker}>{note.speaker}</Text> : null}
      <Text style={styles.noteText}>{note.text}</Text>
    </Animated.View>
  );
}

/**
 * The recording control. Compresses further than a normal CTA (0.9) because
 * it's the heaviest action on screen and should feel like a physical switch.
 *
 * Haptics are fired by the handler rather than PressableScale so the Heavy tick
 * lands with the stop itself, not with every aborted press.
 */
function StopButton({ onPress, paused }: { onPress: () => void; paused: boolean }) {
  return (
    <PressableScale
      haptic={null}
      pressScale={0.9}
      onPress={onPress}
      style={styles.stop}
      accessibilityRole="button"
      accessibilityLabel={paused ? 'Session paused' : 'Stop recording'}
    >
      <View style={styles.stopInner} />
    </PressableScale>
  );
}

/* ------------------------------------------------------------------ */

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },

  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: space.xl,
    paddingBottom: space.md,
  },
  liveGroup: { flexDirection: 'row', alignItems: 'center', width: 92 },
  liveLabel: { ...type.eyebrow, color: colors.live, marginLeft: -2 },
  timer: { ...type.timer, color: colors.text, flex: 1, textAlign: 'center' },
  topBarSpacer: { width: 92, alignItems: 'flex-end' },
  meetingLabel: { ...type.meta, color: colors.textMuted },

  stage: {
    alignItems: 'center',
    paddingVertical: space.xxl,
    marginHorizontal: space.xl,
    borderRadius: radius.xl,
    backgroundColor: colors.surface1,
    borderWidth: 1,
    borderColor: colors.border,
  },
  stageCaption: { ...type.meta, color: colors.textMuted, marginTop: space.xl },

  objectiveStrip: { marginTop: space.xl },
  stripLabel: { ...type.eyebrow, color: colors.textMuted, paddingHorizontal: space.xl, marginBottom: space.sm },
  stripRow: { paddingHorizontal: space.xl, gap: space.sm },
  stripCard: {
    width: 232,
    paddingVertical: space.md,
    paddingHorizontal: space.lg,
    borderRadius: radius.md,
    backgroundColor: alpha.accentGlow,
    borderWidth: 1,
    borderColor: alpha.accentEdge,
  },
  stripText: { ...type.meta, color: '#C7D2FE', lineHeight: 17 },

  feed: { flex: 1, marginTop: space.xl },
  feedContent: { paddingHorizontal: space.xl, paddingBottom: space.xl, gap: space.md },
  feedEmpty: { paddingVertical: space.xxxl, paddingHorizontal: space.lg },
  feedEmptyText: { ...type.body, color: colors.textMuted, lineHeight: 21, textAlign: 'center' },

  note: {
    backgroundColor: colors.surface1,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.lg,
  },
  noteManual: { borderColor: alpha.accentEdge, backgroundColor: alpha.accentGlow },
  noteHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: space.sm,
  },
  noteTime: { ...type.meta, color: colors.textMuted },
  noteSpeaker: { ...type.meta, color: colors.textSecondary, marginBottom: 3 },
  noteText: { ...type.body, color: colors.text, lineHeight: 21 },

  dock: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: space.xxl,
    paddingTop: space.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.surface1,
  },
  dockButton: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 92,
    paddingVertical: space.md,
    borderRadius: radius.md,
    backgroundColor: colors.surface2,
    borderWidth: 1,
    borderColor: colors.border,
  },
  dockGlyph: { marginBottom: 5 },
  dockLabel: { ...type.meta, color: colors.textSecondary },

  stop: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: alpha.liveGlow,
    borderWidth: 2,
    borderColor: colors.live,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.live,
    shadowOpacity: 0.45,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  stopInner: { width: 24, height: 24, borderRadius: 6, backgroundColor: colors.live },

  recapRow: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm, marginBottom: space.xl },
  endButton: {
    backgroundColor: colors.live,
    borderRadius: radius.pill,
    paddingVertical: space.lg,
    alignItems: 'center',
  },
  endButtonText: { ...type.heading, color: colors.text },
  resumeButton: { paddingVertical: space.lg, alignItems: 'center' },
  resumeText: { ...type.body, color: colors.textSecondary },
});
