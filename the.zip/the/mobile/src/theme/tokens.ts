/**
 * Nabla design tokens — "dark-mode executive precision".
 *
 * Every colour, radius and motion curve in the app resolves through here so the
 * visual language stays one system instead of a pile of inline hex codes.
 */

export const colors = {
  /** Deepest obsidian — the app never sits on anything lighter. */
  bg: '#08090A',
  /** Elevation 1: cards resting on the background. */
  surface1: '#121418',
  /** Elevation 2: pressed / hovered / nested surfaces. */
  surface2: '#1A1D24',
  /** Subtle 1px glass strokes. */
  border: '#262A36',
  /** Electric indigo — primary CTA. */
  accent: '#6366F1',
  /** AI signal gradient: violet -> pink glow. */
  aiFrom: '#8B5CF6',
  aiTo: '#EC4899',
  /** Crimson pulse — active recording only. Never decorative. */
  live: '#EF4444',
  /** Live-presence dot. */
  presence: '#22C55E',

  text: '#F9FAFB',
  textSecondary: '#9CA3AF',
  textMuted: '#6B7280',
} as const;

/** Translucent washes used for tinted chips and glows. */
export const alpha = {
  accentGlow: 'rgba(99, 102, 241, 0.16)',
  accentEdge: 'rgba(99, 102, 241, 0.42)',
  aiGlow: 'rgba(139, 92, 246, 0.16)',
  aiEdge: 'rgba(139, 92, 246, 0.40)',
  liveGlow: 'rgba(239, 68, 68, 0.14)',
  liveEdge: 'rgba(239, 68, 68, 0.45)',
  /** Heavy scrim for opaque docks. */
  scrim: 'rgba(8, 9, 10, 0.72)',
  /** Light scrim laid over a BlurView — enough to darken, not enough to hide the blur. */
  scrimSoft: 'rgba(8, 9, 10, 0.35)',
  hairline: 'rgba(249, 250, 251, 0.06)',
} as const;

/** 4pt base scale. Layout uses these exclusively. */
export const space = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
} as const;

export const radius = {
  pill: 999,
  sm: 10,
  md: 14,
  lg: 20,
  xl: 26,
} as const;

/**
 * Type ramp. Tight tracking on display sizes is what reads as "executive"
 * rather than "consumer app".
 */
export const type = {
  display: { fontSize: 30, fontWeight: '700', letterSpacing: -0.8 },
  title: { fontSize: 20, fontWeight: '700', letterSpacing: -0.4 },
  heading: { fontSize: 16, fontWeight: '600', letterSpacing: -0.2 },
  body: { fontSize: 14, fontWeight: '500', letterSpacing: -0.1 },
  meta: { fontSize: 12, fontWeight: '600', letterSpacing: 0.1 },
  /** All-caps eyebrow labels for section headers and pills. */
  eyebrow: { fontSize: 10, fontWeight: '700', letterSpacing: 1.2 },
  /** Tabular-ish numerals for the recording timer. */
  timer: { fontSize: 17, fontWeight: '700', letterSpacing: 0.6 },
} as const;

/**
 * Single spring config, shared by every interactive element. Consistency of
 * motion is what makes the whole app feel like one physical object.
 */
export const spring = { damping: 15, stiffness: 150, mass: 0.6 } as const;

/** Softer spring for content entering the layout, per the motion spec. */
export const layoutSpring = { damping: 14, stiffness: 130, mass: 0.8 } as const;

/** Scale a primary CTA compresses to on press-in. */
export const PRESS_SCALE = 0.96;
