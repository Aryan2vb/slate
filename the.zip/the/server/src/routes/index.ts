import { Router } from 'express';
import { googleAuth } from '../controllers/authController';
import { getEvents } from '../controllers/calendarController';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.post('/api/auth/google', googleAuth);
router.get('/api/calendar/events', authMiddleware, getEvents);

export default router;
