import { google } from 'googleapis';

// ------------------------------------------------------------------
// IMPORTANT: Web Client ID vs Native/Android/iOS Client IDs
// ------------------------------------------------------------------
// When building an app that requires backend API access to Google APIs (like Calendar),
// you MUST use a "Web application" Client ID for the server-side exchange, even if 
// the original authorization happens on a mobile device (iOS/Android).
// 
// Why?
// Native Client IDs (iOS/Android) are designed for public clients and do not have a 
// Client Secret. They are meant for apps where the tokens are kept only on the device.
// Server-side code is a "confidential client" and can securely hold a Client Secret.
// To get an offline refresh token that the server can use indefinitely, the client
// must send an authorization code to the server, and the server exchanges it using 
// the Web Client ID and Web Client Secret.
// ------------------------------------------------------------------

const getOAuth2Client = () => {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.REDIRECT_URI
  );
};

export const exchangeCodeForTokens = async (code: string) => {
  const oauth2Client = getOAuth2Client();
  // The offline access / refresh token pattern:
  // We request access_type: 'offline' on the client side to ensure Google sends us
  // a refresh_token. This token is stored in our database (or memory store) and used
  // to get fresh access tokens whenever we need to call Google APIs in the future,
  // without asking the user to log in again.
  const { tokens } = await oauth2Client.getToken(code);
  return tokens;
};

export const getUserProfile = async (accessToken: string) => {
  const oauth2Client = getOAuth2Client();
  oauth2Client.setCredentials({ access_token: accessToken });
  
  const oauth2 = google.oauth2({
    auth: oauth2Client,
    version: 'v2'
  });

  const res = await oauth2.userinfo.get();
  return res.data;
};

export const getUpcomingEvents = async (refreshToken: string, maxResults = 5) => {
  const oauth2Client = getOAuth2Client();
  oauth2Client.setCredentials({ refresh_token: refreshToken });
  
  // Create an authenticated Calendar client
  const calendar = google.calendar({ version: 'v3', auth: oauth2Client });
  
  const res = await calendar.events.list({
    calendarId: 'primary',
    timeMin: new Date().toISOString(),
    maxResults: maxResults,
    singleEvents: true,
    orderBy: 'startTime',
  });

  const events = res.data.items || [];
  
  return events.map(event => ({
    id: event.id,
    title: event.summary,
    description: event.description,
    startTime: event.start?.dateTime || event.start?.date,
    endTime: event.end?.dateTime || event.end?.date,
    attendeeCount: event.attendees?.length || 0,
    location: event.location,
    htmlLink: event.htmlLink
  }));
};
