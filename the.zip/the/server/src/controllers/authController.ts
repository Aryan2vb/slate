import { Request, Response } from 'express';
import { exchangeCodeForTokens, getUserProfile } from '../services/googleCalendarService';
import { saveUser, getUserByEmail, User } from '../store/userStore';
import jwt from 'jsonwebtoken';
import { OAuth2Client } from 'google-auth-library';

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

export const googleAuth = async (req: Request, res: Response): Promise<void> => {
  try {
    const { code, idToken } = req.body;
    let userProfile: any;
    let refreshToken: string | undefined;

    if (code) {
      const tokens = await exchangeCodeForTokens(code);
      refreshToken = tokens.refresh_token || undefined;
      userProfile = await getUserProfile(tokens.access_token!);
    } else if (idToken) {
      const ticket = await client.verifyIdToken({
        idToken,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      userProfile = ticket.getPayload();
      // Note: No refresh token is obtained in the idToken flow.
      // The client would only be authenticated, but backend won't be able to access Calendar offline.
    } else {
      res.status(400).json({ error: 'Must provide code or idToken' });
      return;
    }

    if (!userProfile || !userProfile.email) {
      res.status(400).json({ error: 'Failed to retrieve user email' });
      return;
    }

    let user: User | undefined = getUserByEmail(userProfile.email);
    
    if (user) {
      if (refreshToken) {
        user.googleRefreshToken = refreshToken;
        saveUser(user);
      }
    } else {
      user = {
        id: userProfile.id || userProfile.sub,
        email: userProfile.email,
        name: userProfile.name,
        picture: userProfile.picture,
        googleRefreshToken: refreshToken
      };
      saveUser(user);
    }

    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '1h' }
    );

    res.status(200).json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        picture: user.picture
      }
    });
  } catch (error) {
    console.error('Google Auth Error:', error);
    res.status(500).json({ error: 'Internal server error during authentication' });
  }
};
