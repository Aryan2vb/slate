import { Request, Response } from 'express';
import { getUser } from '../store/userStore';
import { getUpcomingEvents as fetchEvents } from '../services/googleCalendarService';

export const getEvents = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.user?.userId;
    if (!userId) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    const user = getUser(userId);
    if (!user || !user.googleRefreshToken) {
      res.status(403).json({ error: 'User does not have a Google refresh token' });
      return;
    }

    const events = await fetchEvents(user.googleRefreshToken);
    res.status(200).json({ events });
  } catch (error) {
    console.error('Fetch Events Error:', error);
    res.status(500).json({ error: 'Internal server error while fetching calendar events' });
  }
};
